var searchData=
[
  ['saveto',['SaveTo',['../class_format_factory.html#ac787363aa133a274ae674526dcc2b301',1,'FormatFactory::SaveTo()'],['../class_txt.html#abe4239811b140dd6fc5a439be6964aa0',1,'Txt::SaveTo()'],['../class_doc.html#a00303c942160d3e6f69b38e387f12a03',1,'Doc::SaveTo()']]],
  ['settchk',['SetTchk',['../class_main_window.html#a167ea3c098e223361ff8d2300d71d6ae',1,'MainWindow']]]
];
