var searchData=
[
  ['mainwindow_2eh',['mainwindow.h',['../mainwindow_8h.html',1,'']]],
  ['mydialogcurve_2eh',['mydialogcurve.h',['../mydialogcurve_8h.html',1,'']]]
];
