var searchData=
[
  ['name',['name',['../classgraph.html#abfbbdbd09b20d6ef147ee966b1325595',1,'graph']]],
  ['nameoffile',['NameOfFile',['../class_main_window.html#a212db452b7d30710f776bc89a0a7e3ea',1,'MainWindow']]]
];
