var searchData=
[
  ['delwin',['DelWin',['../class_main_window.html#a2f05d7f42a79bcda8f6e0fd216bf20d0',1,'MainWindow']]],
  ['doc',['Doc',['../class_doc.html',1,'']]]
];
