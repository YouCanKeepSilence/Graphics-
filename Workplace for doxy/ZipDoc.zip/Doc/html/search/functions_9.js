var searchData=
[
  ['textchanged',['TextChanged',['../class_my_new_curve.html#ad2f0b68e3ac43c6046261ad41059edae',1,'MyNewCurve']]]
];
