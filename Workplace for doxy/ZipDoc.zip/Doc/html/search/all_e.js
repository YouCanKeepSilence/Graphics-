var searchData=
[
  ['tchk',['tchk',['../classgraph.html#afae7c6852c8de983693fb2fd108ed3c4',1,'graph']]],
  ['textchanged',['TextChanged',['../class_my_new_curve.html#ad2f0b68e3ac43c6046261ad41059edae',1,'MyNewCurve']]],
  ['txt',['Txt',['../class_txt.html',1,'']]]
];
