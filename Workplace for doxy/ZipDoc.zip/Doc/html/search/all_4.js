var searchData=
[
  ['enablemagnifier',['enableMagnifier',['../class_main_window.html#afdb82afd72e8643eddf6f4c0266489e8',1,'MainWindow']]],
  ['enablemovingonplot',['enableMovingOnPlot',['../class_main_window.html#ad04c0aea2156c338a745b02ac456343b',1,'MainWindow']]],
  ['enablepicker',['enablePicker',['../class_main_window.html#ac532634c85e6e35dfbd7c5d1c1520e62',1,'MainWindow']]]
];
