var searchData=
[
  ['addcurve',['addCurve',['../class_main_window.html#aa5c0998b1192bfab3ff83b02c42b2c67',1,'MainWindow']]],
  ['addfreecurve',['addfreeCurve',['../class_main_window.html#a3d6f33a054126933c27adefd9ea329e0',1,'MainWindow']]],
  ['addplot',['addPlot',['../class_main_window.html#a77cab55db6f0a5b74c9f7d3da47e006f',1,'MainWindow']]],
  ['addplotgrid',['addPlotGrid',['../class_main_window.html#abb03c14d2a968e50a8d069b73f27efb0',1,'MainWindow']]],
  ['appendcurve',['AppendCurve',['../class_main_window.html#a28101a1eab9711200fbf177808d037eb',1,'MainWindow']]],
  ['appendto',['AppendTo',['../class_format_factory.html#ae29ad79ca214f944962094487e668c8c',1,'FormatFactory::AppendTo()'],['../class_txt.html#a4d23910d9b7f36e4f82fdf6045135378',1,'Txt::AppendTo()'],['../class_doc.html#af5c9529b9108d9155b0d725f066b3d67',1,'Doc::AppendTo()']]]
];
