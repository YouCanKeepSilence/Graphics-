var searchData=
[
  ['workwithfiles_2eh',['workwithfiles.h',['../workwithfiles_8h.html',1,'']]]
];
