var searchData=
[
  ['readfrom',['ReadFrom',['../class_format_factory.html#ad3136c43b27e86cf755106381081e67c',1,'FormatFactory::ReadFrom()'],['../class_txt.html#a2109a6bb72b2277dc5eb134a0f4f3257',1,'Txt::ReadFrom()'],['../class_doc.html#aa9359b8e110d9d26bcd25b68e1001743',1,'Doc::ReadFrom()']]],
  ['readonefrom',['ReadOneFrom',['../class_format_factory.html#a0002fa7430aefd926ac94c38155b146e',1,'FormatFactory::ReadOneFrom()'],['../class_txt.html#a1fa6a42957c0e72314c7ba70eb3fab76',1,'Txt::ReadOneFrom()'],['../class_doc.html#a3706c27d55dbb3fe7356a6b5dbb72b5c',1,'Doc::ReadOneFrom()']]],
  ['reshow',['reshow',['../class_main_window.html#a24985964bdf5f59467dcc99749e06bdd',1,'MainWindow']]]
];
