var annotated_dup =
[
    [ "Doc", "class_doc.html", "class_doc" ],
    [ "FormatFactory", "class_format_factory.html", "class_format_factory" ],
    [ "graph", "classgraph.html", "classgraph" ],
    [ "MainWindow", "class_main_window.html", "class_main_window" ],
    [ "MyDeleteCurve", "class_my_delete_curve.html", "class_my_delete_curve" ],
    [ "MyNewCurve", "class_my_new_curve.html", "class_my_new_curve" ],
    [ "Txt", "class_txt.html", "class_txt" ]
];