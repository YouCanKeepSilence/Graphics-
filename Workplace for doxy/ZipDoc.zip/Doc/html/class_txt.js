var class_txt =
[
    [ "AppendTo", "class_txt.html#a4d23910d9b7f36e4f82fdf6045135378", null ],
    [ "ReadFrom", "class_txt.html#a2109a6bb72b2277dc5eb134a0f4f3257", null ],
    [ "ReadOneFrom", "class_txt.html#a1fa6a42957c0e72314c7ba70eb3fab76", null ],
    [ "SaveTo", "class_txt.html#abe4239811b140dd6fc5a439be6964aa0", null ]
];