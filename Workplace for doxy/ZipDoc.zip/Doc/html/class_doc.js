var class_doc =
[
    [ "AppendTo", "class_doc.html#af5c9529b9108d9155b0d725f066b3d67", null ],
    [ "ReadFrom", "class_doc.html#aa9359b8e110d9d26bcd25b68e1001743", null ],
    [ "ReadOneFrom", "class_doc.html#a3706c27d55dbb3fe7356a6b5dbb72b5c", null ],
    [ "SaveTo", "class_doc.html#a00303c942160d3e6f69b38e387f12a03", null ]
];