var hierarchy =
[
    [ "FormatFactory", "class_format_factory.html", [
      [ "Doc", "class_doc.html", null ],
      [ "Txt", "class_txt.html", null ]
    ] ],
    [ "graph", "classgraph.html", null ],
    [ "QDialog", null, [
      [ "MyDeleteCurve", "class_my_delete_curve.html", null ],
      [ "MyNewCurve", "class_my_new_curve.html", null ]
    ] ],
    [ "QMainWindow", null, [
      [ "MainWindow", "class_main_window.html", null ]
    ] ]
];