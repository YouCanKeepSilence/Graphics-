var class_format_factory =
[
    [ "~FormatFactory", "class_format_factory.html#a50e7cffbf326ea0793ef36f8d42ab99d", null ],
    [ "AppendTo", "class_format_factory.html#ae29ad79ca214f944962094487e668c8c", null ],
    [ "ReadFrom", "class_format_factory.html#ad3136c43b27e86cf755106381081e67c", null ],
    [ "ReadOneFrom", "class_format_factory.html#a0002fa7430aefd926ac94c38155b146e", null ],
    [ "SaveTo", "class_format_factory.html#ac787363aa133a274ae674526dcc2b301", null ]
];