var classgraph =
[
    [ "graph", "classgraph.html#a6aaa56b4528d2fdb8f0ecd97e04f6651", null ],
    [ "FindNear", "classgraph.html#a69b8295dbfe6bcfab5050e3fdcc257f2", null ],
    [ "MoveFromBackWithout", "classgraph.html#af46434aacc2b15519b6a25943570ce05", null ],
    [ "blue", "classgraph.html#a2007891f138555cc8be9ca822b9fa2db", null ],
    [ "curva", "classgraph.html#abbfdc5f6022afe7be261bf927498e92e", null ],
    [ "green", "classgraph.html#abb30b4156f98b6e0046f7192c389e4e4", null ],
    [ "name", "classgraph.html#abfbbdbd09b20d6ef147ee966b1325595", null ],
    [ "pen", "classgraph.html#a237fa656ed0f8909b8eadd22aaeff422", null ],
    [ "red", "classgraph.html#aa3334acd551b2fc61901c2afdd4b2d8f", null ],
    [ "tchk", "classgraph.html#afae7c6852c8de983693fb2fd108ed3c4", null ]
];