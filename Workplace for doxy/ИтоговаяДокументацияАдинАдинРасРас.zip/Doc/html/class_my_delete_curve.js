var class_my_delete_curve =
[
    [ "MyDeleteCurve", "class_my_delete_curve.html#af14574f71c84bf83931e5a9f3c124361", null ],
    [ "cancel", "class_my_delete_curve.html#a52214e1db933064bb5770ec3e55e982c", null ],
    [ "Final", "class_my_delete_curve.html#ac6f2498b84a6196601fb2aa8c6465ff1", null ],
    [ "Lone", "class_my_delete_curve.html#abd945d4ef22afe07394b8cd8711b538c", null ],
    [ "Ltwo", "class_my_delete_curve.html#a2c5bf4e6debf39d4a9823cac92d0c36a", null ],
    [ "ok", "class_my_delete_curve.html#ad68069811a82e7652005a8bef1a4eea5", null ],
    [ "text", "class_my_delete_curve.html#a6c229d6cb0a65941ea33d6c4553b827b", null ]
];