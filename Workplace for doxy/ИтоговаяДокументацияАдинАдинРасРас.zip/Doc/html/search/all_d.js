var searchData=
[
  ['savetodoc',['SaveToDoc',['../class_main_window.html#aa84cdb1ab42ba6621bf43fc2d126bcf4',1,'MainWindow']]],
  ['savetotxt',['SaveToTxt',['../class_main_window.html#a64f7c1216a075bf75d3c2e7fb88fd371',1,'MainWindow']]]
];
