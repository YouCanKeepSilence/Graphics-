var searchData=
[
  ['readfromdoc',['ReadFromDoc',['../class_main_window.html#a219bfb3f9f9946118aaebb0e88f64315',1,'MainWindow']]],
  ['readfromtxt',['ReadFromTxt',['../class_main_window.html#ac280af7b364789fa7b6e2274fb8a9e2a',1,'MainWindow']]],
  ['readonefromdoc',['ReadOneFromDoc',['../class_main_window.html#a72ec1547630d1af06f61888bb623fad6',1,'MainWindow']]],
  ['readonefromtxt',['ReadOneFromTxt',['../class_main_window.html#a50c6d26a5751b97d502334de0c43fcef',1,'MainWindow']]],
  ['reshow',['reshow',['../class_main_window.html#a24985964bdf5f59467dcc99749e06bdd',1,'MainWindow']]]
];
