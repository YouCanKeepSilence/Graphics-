var searchData=
[
  ['checkvector',['CheckVector',['../class_main_window.html#a236bdec985319b80062b14e4e53bf2a0',1,'MainWindow']]],
  ['click_5fon_5fcanvas',['click_on_canvas',['../class_main_window.html#aa518cb3e5c52da2ccb6b886d6e09339d',1,'MainWindow']]]
];
