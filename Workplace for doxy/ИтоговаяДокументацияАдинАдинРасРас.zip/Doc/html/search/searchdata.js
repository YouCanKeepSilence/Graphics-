var indexSectionsWithContent =
{
  0: "abcdefglmnoprstu",
  1: "gm",
  2: "m",
  3: "acefgmorst",
  4: "bcdfglnprtu"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "Указатель",
  1: "Классы",
  2: "Файлы",
  3: "Функции",
  4: "Переменные"
};

