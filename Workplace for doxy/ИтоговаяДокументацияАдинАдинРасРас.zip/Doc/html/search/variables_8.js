var searchData=
[
  ['red',['red',['../classgraph.html#aa3334acd551b2fc61901c2afdd4b2d8f',1,'graph']]]
];
