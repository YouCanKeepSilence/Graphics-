var searchData=
[
  ['addcurve',['addCurve',['../class_main_window.html#aa5c0998b1192bfab3ff83b02c42b2c67',1,'MainWindow']]],
  ['addfreecurve',['addfreeCurve',['../class_main_window.html#a3d6f33a054126933c27adefd9ea329e0',1,'MainWindow']]],
  ['addplot',['addPlot',['../class_main_window.html#a77cab55db6f0a5b74c9f7d3da47e006f',1,'MainWindow']]],
  ['addplotgrid',['addPlotGrid',['../class_main_window.html#abb03c14d2a968e50a8d069b73f27efb0',1,'MainWindow']]],
  ['appendtodoc',['AppendToDoc',['../class_main_window.html#ab31b6edb24cdb7744f4ab4db3300b29c',1,'MainWindow']]],
  ['appendtotxt',['AppendToTxt',['../class_main_window.html#ada72ba7c0365cd69528339a0298941d2',1,'MainWindow']]]
];
