var searchData=
[
  ['litwin',['litwin',['../class_main_window.html#a974a3a4a0c5646eca195d209856079dc',1,'MainWindow']]]
];
