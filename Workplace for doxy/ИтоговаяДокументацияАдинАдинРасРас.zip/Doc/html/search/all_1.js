var searchData=
[
  ['base',['base',['../class_main_window.html#a3413d4508f4981518b1b8ebf3b29121e',1,'MainWindow']]],
  ['blue',['blue',['../classgraph.html#a2007891f138555cc8be9ca822b9fa2db',1,'graph']]]
];
