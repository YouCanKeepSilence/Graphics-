var searchData=
[
  ['mainwindow',['MainWindow',['../class_main_window.html',1,'']]],
  ['mydeletecurve',['MyDeleteCurve',['../class_my_delete_curve.html',1,'']]],
  ['mynewcurve',['MyNewCurve',['../class_my_new_curve.html',1,'']]]
];
