var annotated_dup =
[
    [ "graph", "classgraph.html", "classgraph" ],
    [ "MainWindow", "class_main_window.html", "class_main_window" ],
    [ "MyDeleteCurve", "class_my_delete_curve.html", "class_my_delete_curve" ],
    [ "MyNewCurve", "class_my_new_curve.html", "class_my_new_curve" ]
];