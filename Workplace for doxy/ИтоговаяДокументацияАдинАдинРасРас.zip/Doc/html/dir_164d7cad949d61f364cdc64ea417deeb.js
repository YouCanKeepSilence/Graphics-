var dir_164d7cad949d61f364cdc64ea417deeb =
[
    [ "main.cpp", "main_8cpp_source.html", null ],
    [ "mainwindow.cpp", "mainwindow_8cpp_source.html", null ],
    [ "mainwindow.h", "mainwindow_8h.html", [
      [ "graph", "classgraph.html", "classgraph" ],
      [ "MainWindow", "class_main_window.html", "class_main_window" ]
    ] ],
    [ "mydialogcurve.cpp", "mydialogcurve_8cpp_source.html", null ],
    [ "mydialogcurve.h", "mydialogcurve_8h.html", [
      [ "MyNewCurve", "class_my_new_curve.html", "class_my_new_curve" ],
      [ "MyDeleteCurve", "class_my_delete_curve.html", "class_my_delete_curve" ]
    ] ]
];