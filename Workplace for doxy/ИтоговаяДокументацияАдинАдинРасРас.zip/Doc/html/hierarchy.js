var hierarchy =
[
    [ "graph", "classgraph.html", null ],
    [ "QDialog", null, [
      [ "MyDeleteCurve", "class_my_delete_curve.html", null ],
      [ "MyNewCurve", "class_my_new_curve.html", null ]
    ] ],
    [ "QMainWindow", null, [
      [ "MainWindow", "class_main_window.html", null ]
    ] ]
];